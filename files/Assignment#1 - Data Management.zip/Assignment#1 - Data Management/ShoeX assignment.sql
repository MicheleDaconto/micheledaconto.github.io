--- Create view for the corrected final price ---

-- In the original DB, in case there is discount at item level, 
-- the finalprice is the amount of discount applied to each item sold
-- (taking into consideration also the quantity). 
-- If instead there is no discount at item level, then totalprice = finalprice

-- We want the finalprice to be the actual final price, not the discount to be subtracted
-- from the total price
-- ex:
-- Before: totalprice = 10, discount = 20%, finalprice = 2
-- After: totalprice = 10, discount = 20%, finalprice = 10-2 = 8

--- We create the view to store the corrected_finalprice:
CREATE VIEW view_corrected_finalprice AS
SELECT 
    saleitem.saleitemid,
    -- Corrected finalprice based on discount
    CASE 
        WHEN saleitem.discountpct > 0 THEN (saleitem.totalprice - saleitem.finalprice)
        ELSE saleitem.finalprice
    END AS corrected_finalprice
FROM saleitem;


--- Create view for the corrected for discount price on saleitem ---

-- In the original DB, when discountpct at saleitem = 0
-- the finalprice column holds the same value as totalprice.
-- If there is a discount, the finalprice column shows the discount amount calculated as
-- discountpct * totalprice / 100.
-- We want the discount_itemprice to be the actual discountprice at item level

-- We create the view to store the corrected discount_itemprice:
CREATE VIEW view_corrected_discountitemprice AS
SELECT
    si.saleitemid,
    si.transactionid,
    -- corrected discountprice based on discount
    CASE
        WHEN si.discountpct > 0 THEN (si.finalprice)
        ELSE 0
    END AS corrected_discountitemprice
FROM saleitem si;


--- Create the final view for saleitem applying the conversion rates ---

-- In the original DB, there are 3 different currency used.
-- For the sake of comparison, it is better to have all the data in one currency.
-- We then use the currency code information to apply the conversion
-- to both totalprice and corrected_finalprice.

--- We create the view
CREATE VIEW view_saleitem AS
SELECT 
    si.saleitemid,
    si.transactionid,
    si.categoryid,
    si.itemprice,
    si.quantity,
    si.discountpct,
    si.campaignprice,
    si.sizeofshoe,
    vc.corrected_finalprice,
    si.totalprice,
	si.finalprice,
    -- Currency conversion for totalprice
    CASE
        WHEN st.currencycode = 'NOK' THEN (si.totalprice * 0.64)
        WHEN st.currencycode = 'SEK' THEN (si.totalprice * 0.66)
        WHEN st.currencycode = 'DKK' THEN si.totalprice
    END AS converted_totalprice,
	-- Currency conversion for corrected discountprice (discount on saleitem)
	CASE
		WHEN st.currencycode = 'NOK' THEN (vcd.corrected_discountitemprice * 0.64)
        WHEN st.currencycode = 'SEK' THEN (vcd.corrected_discountitemprice * 0.66)
        WHEN st.currencycode = 'DKK' THEN vcd.corrected_discountitemprice
    END AS converted_disc_itemprice,
    -- Currency conversion for corrected finalprice
    CASE
        WHEN st.currencycode = 'NOK' THEN (vc.corrected_finalprice * 0.64)
        WHEN st.currencycode = 'SEK' THEN (vc.corrected_finalprice * 0.66)
        WHEN st.currencycode = 'DKK' THEN vc.corrected_finalprice
    END AS converted_finalprice
FROM saleitem si
JOIN view_corrected_finalprice vc ON si.saleitemid = vc.saleitemid
JOIN view_corrected_discountitemprice vcd ON si.saleitemid = vcd.saleitemid
JOIN saletransaction st ON si.transactionid = st.transactionid;


--- Create a view for the totalprice at transaction level ---

-- We first calcualate the totalprice at transaction level when discount is still not applied.
-- We will use it to later create the view with the finalprice at transaction level when also
-- discount is applied.

--- We create the view to store the totalprice at transaction level:
CREATE VIEW view_transaction_totalprice AS
SELECT 
    vsi.transactionid,
    SUM(vsi.converted_finalprice) AS transaction_totalprice
FROM view_saleitem vsi
GROUP BY vsi.transactionid;


--- Create the final view for saletransaction to store also the transaction_finalprice ---

-- We store all the data from saletransaction, we include also transaction_totalprice from
-- view_transaction_totalprice, and we use it to calculate the transaction_finalprice
-- applying also the discount at transaction level.

--- We create the view
CREATE VIEW view_saletransaction AS
SELECT 
    st.*,
    vtf.transaction_totalprice,
    -- Calculate the discount applied at the transaction level
    ROUND(vtf.transaction_totalprice * st.discountpct / 100, 4) as converted_disc_transactionprice,
    -- Calculate the final price after applying the discount
    ROUND(vtf.transaction_totalprice - (vtf.transaction_totalprice * st.discountpct / 100), 4) 
    AS transaction_finalprice
FROM saletransaction st
JOIN view_transaction_totalprice vtf ON st.transactionid = vtf.transactionid;


--- Q1: View Star Schema
-- View DimProduct
create view dim_product as
select 
    si.saleitemid, -- PK
    si.sizeofshoe  
from view_saleitem si;

-- View DimStore
create view dim_store as
select 
    s.storeid, -- PK
    s.storename, 
    s.country
from storeinfo s;

-- View DimSaleschannel
create view dim_sales_channel as
select 
    sc.saleschannelid, -- PK
    sc.saleschannelname
from saleschannel sc;

-- View DimCategory
create view dim_category as
select
    cm.categorymapid, -- PK
	mc.categoryid,
    mc.categoryname,  
    sc.subcategoryid, 
    sc.subcategoryname
from categorymap cm
join maincategory mc on cm.maincategoryid = mc.categoryid
join subcategory sc on cm.subcategoryid = sc.subcategoryid;

-- View FactSale
create view fact_sales as
select 
    si.saleitemid, -- FK
    st.storeid, -- FK
    st.saleschannelid, -- FK
    cm.categorymapid, -- FK
    st.transactionid, 
    si.itemprice, 
    si.converted_totalprice,  
    si.converted_finalprice,
    si.discountpct as discount_si,
    st.discountpct as discount_st,
	st.transaction_totalprice,
	st.transaction_finalprice
from view_saletransaction st
join view_saleitem si on st.transactionid = si.transactionid
join categorymap cm on si.categoryid = cm.categorymapid;


--- Q1: Report - extracting tables through SQL queries and views
-- Report Non-Discounted Sales Only for Shoe Sizes
select
    dp.sizeofshoe, 
    count (fs.saleitemid) as total_sales,
	sum(fs.converted_finalprice) as revenue
from fact_sales as fs
join dim_product dp on fs.saleitemid = dp.saleitemid
where fs.discount_si = 0 and fs.discount_st = 0
group by 1
order by 1;

-- Report Non-Discounted Sales on Different Sales Channels
select 
    dsc.saleschannelname, 
    count(fs.saleitemid) as total_sales,
	sum(fs.transaction_finalprice) as revenue
from fact_sales as fs
join dim_sales_channel dsc on fs.saleschannelid = dsc.saleschannelid
where fs.discount_si = 0 and fs.discount_st = 0
group by 1
order by 2 desc;


-- Report Non-Discounted Sales in Different Countries
select 
    ds.country, 
    count(fs.saleitemid) as total_sales, 
	sum(fs.transaction_finalprice) as revenue
from fact_sales as fs
join dim_store ds on fs.storeid = ds.storeid
where fs.discount_si = 0 and fs.discount_st = 0
group by 1
order by 2 desc;


-- Report Non-Discounted Sales on Different Stores
select
    ds.storename, 
    count(fs.saleitemid) as total_sales,
	sum(fs.transaction_finalprice) as revenue
from fact_sales as fs
join dim_store ds on fs.storeid = ds.storeid
where fs.discount_si = 0 and fs.discount_st = 0
group by 1
order by 2 desc;

-- Report Discounted Sales Through Different Sales Channels
select 
    dsc.saleschannelname as sales_channel,
    count(fs.saleitemid) as number_of_discounted_items,
	sum(fs.transaction_finalprice) as revenue
from fact_sales as fs
join dim_sales_channel dsc on fs.saleschannelid = dsc.saleschannelid
where fs.discount_si > 0 or fs.discount_st > 0
group by 1;

-- Report Non-Discounted Sales for Main and Subcategories
select 
    dc.categoryname as main_category, 
    dc.subcategoryname as sub_category, 
    count(fs.saleitemid) as total_sales, 
	sum(fs.transaction_finalprice) as revenue
from fact_sales as fs
join dim_category dc on fs.categorymapid = dc.categorymapid
where fs.discount_si = 0 and fs.discount_st = 0
group by 1, 2
order by 3 desc;


--- Q2: SQL reports
--- a) In which month across all the years (of the ShoeX dataset) the smallest amount 
---    accumulatively was given as discount?
select 
    extract(month from vst.purchasedate) as purchasemonth,  
    extract(year from vst.purchasedate) as purchaseyear,    
    sum(vsi.converted_disc_itemprice + vst.converted_disc_transactionprice) as total_discount
from view_saleitem vsi                                            
join view_saletransaction vst on vsi.transactionid = vst.transactionid  
group by 1, 2
order by 3 asc                                  
limit 1;

--- b) Which Shoe sizes have been sold the least (with respect to the number of pairs sold)
---    per country across all years?
select storeinfo.country, si.sizeofshoe, sum(si.quantity) as total_sold
from view_saleitem si
join saletransaction on si.transactionid = saletransaction.transactionid
join storeinfo on saletransaction.storeid = storeinfo.storeid
group by 1, 2
order by 3
limit 3;

--- c) Which three customers have given the highest revenue at ShoeX in each country? 
select * 
from 
    (select 
        c.name,                           
        s.country,                        
        sum(vst.transaction_finalprice) as totalrevenue, 
        rank() over (partition by s.country 
		order by sum(vst.transaction_finalprice) desc) as revenue_rank  
    from customer c                              
    join view_saletransaction vst on c.customerid = vst.customerid   
    join storeinfo s on s.storeid = vst.storeid           
    group by 1, 2
    ) as ranked_customers
where revenue_rank <= 3
order by ranked_customers.country, totalrevenue desc;


--- d) Are there any Shoe subcategories not sold in 2021 across all countries?
select distinct(cm.subcategoryid), sc.subcategoryname, s.country
from categorymap as cm
join subcategory sc on cm.subcategoryid = sc.subcategoryid
join saleitem si on cm.categorymapid = si.categoryid
join saletransaction st on si.transactionid = st.transactionid
join storeinfo s on st.storeid = s.storeid
where cm.categorymapid not in (
    select si.categoryid
    from view_saleitem si
    join saletransaction on si.transactionid = saletransaction.transactionid
    join storeinfo s on saletransaction.storeid = s.storeid
    where extract(year from saletransaction.purchasedate) = 2021
)
order by 1;
-- test it by using 2019 or different years rather than 2021


--- e) List the customers who purchased from ShoeX more than 4 times across all the years.
select customer.name, count(st.transactionid) as total_purchases
from customer
join saletransaction st on customer.customerid = st.customerid
group by customer.customerid
having count(transactionid) > 4
order by 1;
-- test it by checking over less number of purchases (ex. 1)


--- f) What is the total revenue generated by each payment method across all years and all
---    countries?
select pm.paymentmethodid, pm.paymentmethodname, sum(vst.transaction_finalprice) as total_revenue
from paymentmethod as pm
join view_saletransaction vst on pm.paymentmethodid = vst.paymentmethodid  
join storeinfo s on vst.storeid = s.storeid
group by 1
order by 3 desc;


